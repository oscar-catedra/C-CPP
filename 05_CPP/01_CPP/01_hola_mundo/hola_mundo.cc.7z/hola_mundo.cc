
#include <iostream>

int main() {
    std::cout << "Hola Mundo" << std::endl;
    return 0;
}

// Referencia
//
// OpenAI. (2025, abril 9). Ejemplos en Lenguaje C y C++ [Chat]. ChatGPT. 
// https://www.openai.com/chatgpt

// g++ hola_mundo.cc -o hola_mundo.exe
//

