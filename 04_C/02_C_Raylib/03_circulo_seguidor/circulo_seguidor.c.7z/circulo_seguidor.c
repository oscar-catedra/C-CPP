// archivo: circulo_seguidor.c
#include "raylib.h"

int main(void) {
    const int screenWidth = 800;
    const int screenHeight = 450;

    InitWindow(screenWidth, screenHeight, "Raylib C - Circulo seguidor");

    Color circleColor = RED;

    SetTargetFPS(60);
    while (!WindowShouldClose()) {
        Vector2 mousePos = GetMousePosition();

        if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
            circleColor = (circleColor.r == RED.r) ? BLUE : RED;
        }

        BeginDrawing();
            ClearBackground(RAYWHITE);
            DrawText("Haz clic izquierdo para cambiar el color del círculo", 10, 10, 20, DARKGRAY);
            DrawCircleV(mousePos, 40, circleColor);
        EndDrawing();
    }

    CloseWindow();

    return 0;
}


