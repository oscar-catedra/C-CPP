
#include <stdio.h>

int main() {
    printf("Hola Mundo\n");
    return 0;
}

// https://chatgpt.com/share/67f6b4cb-0b00-800a-a1e4-4c80ddc8453d

// gcc hola_mundo.c -o hola_mundo.exe

